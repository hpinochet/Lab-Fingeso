import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

import axios from 'axios';
import vueAxios from 'vue-axios';

Vue.use(vueAxios, axios); //se pueden hacer peticiones http

new Vue({
  render: function (h) { return h(App) },
}).$mount('#app')
